package Sproutly.Controllers;

import Sproutly.Models.Account;

public interface UserAware {
    void setUser(Account user);
}
